package com.hackerrank.tradingplatform.controller;

import com.hackerrank.tradingplatform.dto.AddMoneyTraderDTO;
import com.hackerrank.tradingplatform.dto.TraderDTO;
import com.hackerrank.tradingplatform.dto.UpdateTraderDTO;
import com.hackerrank.tradingplatform.model.Trader;
import com.hackerrank.tradingplatform.service.TraderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import static java.util.stream.Collectors.toList;

@RestController
@RequestMapping(value = "/trading/traders")
public class TraderController {
    @Autowired
    private TraderService traderService;

    //register
    @RequestMapping(value = "/register", method = RequestMethod.POST, consumes = "application/json")
    public ResponseEntity<?> registerTrader(@RequestBody @Valid Trader trader) {
        Trader t= traderService.getTraderByEmail(trader.getEmail());
        if (t.getEmail() == null)
        {
            return ResponseEntity.status(HttpStatus.CREATED).body(traderService.registerTrader(trader));
        }else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("");
        }
    }

    //get by email
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<?> getTraderByEmail(@RequestParam("email") String email) {
        Trader trader= traderService.getTraderByEmail(email);
        if (trader.getEmail() != null){
            return ResponseEntity.status(HttpStatus.OK).body(trader);
        }
        else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("");
        }
    }

    //get all
    @RequestMapping(value = "/all", method = RequestMethod.GET)
    public ResponseEntity<List<TraderDTO>> getAllTraders() {
        List<TraderDTO> out = traderService.getAllTraders().stream().sorted(Comparator.comparing(Trader::getId))
                .map(TraderDTO::new).collect(toList());
        return ResponseEntity.status(HttpStatus.OK).body(out);
    }

    //update by email
    @RequestMapping(method = RequestMethod.PUT)
    public ResponseEntity<?> updateTrader(@RequestBody @Valid UpdateTraderDTO trader) {
        if (traderService.getTraderByEmail(trader.getEmail()).getEmail() == null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("");
        }else {
            traderService.updateTrader(trader);
            return ResponseEntity.status(HttpStatus.OK).body("");
        }
    }

    //add money
    @RequestMapping(value = "/add", method = RequestMethod.PUT)
    public ResponseEntity<?> addMoney(@RequestBody @Valid AddMoneyTraderDTO trader) {
        if (traderService.getTraderByEmail(trader.getEmail()).getEmail() == null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("");
        }else {
            traderService.addMoney(trader);
            return ResponseEntity.status(HttpStatus.OK).body("");
        }
    }
}
